# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Dev\\flutter_windows_3.29.1-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\ISMAEL\\Documents\\GitHub\\app_previo_integra\\integra_app" PROJECT_DIR)

set(FLUTTER_VERSION "3.0.0+3" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 3 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 3 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Dev\\flutter_windows_3.29.1-stable\\flutter"
  "PROJECT_DIR=C:\\Users\\ISMAEL\\Documents\\GitHub\\app_previo_integra\\integra_app"
  "FLUTTER_ROOT=C:\\Dev\\flutter_windows_3.29.1-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\ISMAEL\\Documents\\GitHub\\app_previo_integra\\integra_app\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\ISMAEL\\Documents\\GitHub\\app_previo_integra\\integra_app"
  "FLUTTER_TARGET=C:\\Users\\ISMAEL\\Documents\\GitHub\\app_previo_integra\\integra_app\\lib\\main.dart"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\ISMAEL\\Documents\\GitHub\\app_previo_integra\\integra_app\\.dart_tool\\package_config.json"
)
